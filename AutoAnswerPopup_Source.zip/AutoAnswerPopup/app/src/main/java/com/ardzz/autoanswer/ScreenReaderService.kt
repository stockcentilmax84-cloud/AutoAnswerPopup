package com.ardzz.autoanswer

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class ScreenReaderService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event tidak dikirim ke server. Pembacaan konten hanya terjadi saat tombol ditekan.
        if (bubble == null) showBubble()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        bubble?.let { windowManager.removeView(it) }
        bubble = null
        executor.shutdown()
        super.onDestroy()
    }

    private fun showBubble() {
        if (bubble != null) return
        val button = Button(this).apply {
            text = "AI"
            textSize = 14f
            setOnClickListener { readAndAnswer() }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 220
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = params.x; startY = params.y; moved = false
                        return false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (downX - e.rawX).toInt()
                        val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                        if (moved) {
                            params.x = (startX + dx).coerceAtLeast(0)
                            params.y = (startY + dy).coerceAtLeast(0)
                            windowManager.updateViewLayout(button, params)
                        }
                        return moved
                    }
                    MotionEvent.ACTION_UP -> return moved
                }
                return false
            }
        })
        bubble = button
        try { windowManager.addView(button, params) } catch (_: Exception) { bubble = null }
    }

    private fun readAndAnswer() {
        if (busy) return
        val key = getSharedPreferences("settings", MODE_PRIVATE).getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            Toast.makeText(this, "Isi API key dulu di aplikasi", Toast.LENGTH_LONG).show()
            return
        }
        val root = rootInActiveWindow
        val captured = StringBuilder()
        if (root != null) collectText(root, captured)
        root?.recycle()
        val screenText = captured.toString().trim().take(12000)
        if (screenText.length < 3) {
            Toast.makeText(this, "Teks tidak terbaca. Coba halaman lain yang teksnya bisa dipilih.", Toast.LENGTH_LONG).show()
            return
        }
        busy = true
        Toast.makeText(this, "AI sedang menganalisis teks layar…", Toast.LENGTH_SHORT).show()
        executor.execute {
            val result = askDeepSeek(key, screenText)
            runOnUiThread {
                busy = false
                showAnswer(result)
            }
        }
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let {
            if (out.length < 12000) out.append(it).append('\n')
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out)
            child.recycle()
        }
    }

    private fun askDeepSeek(apiKey: String, text: String): String {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().apply {
                put("model", "deepseek-chat")
                put("messages", JSONArray().put(JSONObject().apply {
                    put("role", "system")
                    put("content", "Kamu adalah asisten belajar. Identifikasi pertanyaan dari teks layar. Berikan jawaban yang akurat, ringkas, dan jelaskan langkahnya. Jika tidak ada pertanyaan yang jelas, minta pengguna membuka materi atau pertanyaan yang ingin dipelajari.")
                }).put(JSONObject().apply {
                    put("role", "user")
                    put("content", "Teks yang terbaca dari layar:\n$text")
                }))
                put("temperature", 0.2)
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                "API error ${connection.responseCode}: ${response.take(700)}"
            } else {
                JSONObject(response).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            }
        } catch (e: Exception) {
            "Gagal menghubungi AI: ${e.message ?: "periksa koneksi dan API key"}"
        } finally {
            connection?.disconnect()
        }
    }

    private fun showAnswer(answer: String) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 20)
            setBackgroundColor(0xFF20202A.toInt())
        }
        content.addView(TextView(this).apply {
            text = "HASIL AI"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        })
        content.addView(TextView(this).apply {
            text = answer
            textSize = 15f
            setTextColor(0xFFF4F4F4.toInt())
            setPadding(0, 12, 0, 12)
        })
        content.addView(Button(this).apply {
            text = "Tutup"
            setOnClickListener {
                try { windowManager.removeView(content) } catch (_: Exception) {}
            }
        })
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.35f
        }
        try { windowManager.addView(content, params) }
        catch (_: Exception) { Toast.makeText(this, answer.take(2500), Toast.LENGTH_LONG).show() }
    }
}
