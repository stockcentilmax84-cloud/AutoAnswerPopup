package com.ardzz.autoanswer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply {
            text = "AUTO ANSWER POPUP"
            textSize = 23f
            setPadding(0, 12, 0, 18)
        })
        layout.addView(TextView(this).apply {
            text = "Masukkan DeepSeek API key. Kunci disimpan lokal di perangkat."
            textSize = 14f
        })
        val keyInput = EditText(this).apply {
            hint = "DeepSeek API key"
            inputType = 129
            setText(prefs.getString("api_key", ""))
        }
        layout.addView(keyInput)
        val save = Button(this).apply {
            text = "Simpan API Key"
            setOnClickListener {
                prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "API key disimpan", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(save)
        layout.addView(Button(this).apply {
            text = "1. Izinkan tampil di atas aplikasi lain"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Aktifkan Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "\nSetelah kedua izin aktif, tombol AI akan muncul sebagai popup. Buka halaman materi/soal, lalu tekan tombol AI untuk membaca teks yang terlihat."
            textSize = 14f
        })
        layout.addView(TextView(this).apply {
            text = "\nPrivasi: teks layar hanya dikirim ke DeepSeek setelah tombol AI ditekan. Jangan gunakan pada layar berisi password, chat pribadi, atau informasi sensitif."
            textSize = 12f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
