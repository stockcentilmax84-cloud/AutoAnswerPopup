# Auto Answer Popup — Android source

Project Android native Kotlin untuk asisten belajar dengan floating popup dan DeepSeek API.

## Fitur
- Tombol AI melayang dan bisa digeser.
- Saat tombol AI ditekan, aplikasi membaca teks yang tersedia pada accessibility tree layar aktif.
- Teks dikirim ke DeepSeek hanya setelah tindakan pengguna.
- Jawaban tampil dalam popup; tersedia tombol tutup.
- API key disimpan lokal melalui SharedPreferences.

## Persyaratan
- Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- DeepSeek API key milik sendiri.

## Cara menjalankan
1. Ekstrak ZIP lalu buka folder `AutoAnswerPopup` di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Jalankan ke perangkat Android (Android 8.0+).
4. Buka aplikasi, masukkan DeepSeek API key, lalu tekan **Simpan API Key**.
5. Izinkan **tampil di atas aplikasi lain**.
6. Aktifkan **Auto Answer Screen Reader** di pengaturan Accessibility Android.
7. Buka halaman materi/pertanyaan, lalu tekan tombol AI melayang.

## Catatan penting
- Ini adalah source project, bukan APK yang sudah dikompilasi atau diuji di perangkat.
- Tidak semua aplikasi menyediakan teks melalui Accessibility. Konten di canvas, gambar, video, atau aplikasi yang membatasi aksesibilitas mungkin tidak terbaca. Versi ini belum memakai OCR screenshot.
- Tombol popup hanya membaca layar ketika ditekan. Jangan gunakan pada halaman yang menampilkan password, data pribadi, atau percakapan privat.
- Jangan membagikan API key. Penggunaan API dapat dikenai biaya sesuai akun DeepSeek.
- Untuk rilis publik, sebaiknya pindahkan API key ke backend milik sendiri; menyimpan key di aplikasi klien tidak sepenuhnya aman.
